PORTFOLIO NBIOGBE KOMI THIBAUT — VERSION PRO
Palette : bleu nuit + or champagne + ivoire.
Remplace le bloc "Votre photo" par ta vraie photo lorsque tu es prêt.
Le site est responsive téléphone/tablette/ordinateur.
